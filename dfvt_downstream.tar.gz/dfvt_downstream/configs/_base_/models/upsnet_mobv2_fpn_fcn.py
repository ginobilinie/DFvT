# model settings
norm_cfg = dict(type='BN', requires_grad=False)
model = dict(
    type='Upsnet',
    pretrained='workspace/models/pretrained/pytorch/mobilenetv2/\
mobilenetv2_0.75.pth',
    backbone=dict(type='MobileNetV2', width_mult=0.75),
    neck=dict(
        type='FPN', in_channels=[24, 24, 72, 240], num_outs=5,
        out_channels=24),
    rpn_head=dict(
        type='RPNAtssDeviceHead',
        in_channels=24,
        feat_channels=24,
        use_depthwise=True,
        share_head=False,
        anchor_generator=dict(
            type='AnchorGenerator',
            scales=[4],
            ratios=[0.25, 0.5, 1.0, 2.0, 4.0],
            strides=[4, 8, 16, 32, 64]),
        bbox_coder=dict(
            type='DeltaXYWHBBoxCoder',
            target_means=[.0, .0, .0, .0],
            target_stds=[1.0, 1.0, 1.0, 1.0]),
        loss_cls=dict(
            type='CrossEntropyLoss', use_sigmoid=True, loss_weight=1.0),
        loss_bbox=dict(type='L1Loss', loss_weight=1.0)),
    roi_head=dict(
        type='StandardRoIHead',
        bbox_roi_extractor=dict(
            type='SingleRoIExtractor',
            roi_layer=dict(
                type='RoIAlign',
                output_size=7,
                sampling_ratio=2,
                aligned=False,
                use_torchvision=False),
            out_channels=24,
            featmap_strides=[4, 8, 16, 32],
            finest_scale=28),
        bbox_head=dict(
            type='SharedFCBBoxHead',
            fc_out_channels=128,
            in_channels=24,
            num_classes=13,
            num_shared_fcs=1,
            roi_feat_size=7,
            bbox_coder=dict(
                type='DeltaXYWHBBoxCoder',
                target_means=[0., 0., 0., 0.],
                target_stds=[0.1, 0.1, 0.2, 0.2]),
            reg_class_agnostic=False,
            loss_cls=dict(
                type='CrossEntropyLoss',
                use_sigmoid=False,
                loss_weight=1.0,
                class_weight=[3, 3, 3, 3, 3, 1, 3, 3, 3, 3, 3, 3, 1]),
            loss_bbox=dict(type='WeightedSmoothL1Loss', loss_weight=1.0))),
    seg_head=dict(
        type='SemanticRoadmaskHead',
        in_channels=[24, 24, 24],
        channels=12,
        in_index=[0, 1, 2],
        num_classes=13,
        num_sseg_classes=17,
        dropout_ratio=0.1,
        input_transform='resize_concat',
        loss_decode=dict(type='Dice_Ohem', use_sigmoid=False, loss_weight=0.2),
        loss_roadmask=dict(
            type='CrossEntropyLoss', use_sigmoid=True, loss_weight=1.0)),
    train_cfg=dict(
        rpn=dict(
            assigner=dict(type='ATSSAssigner', topk=9),
            sampler=dict(
                type='RandomSampler',
                num=256,
                pos_fraction=0.5,
                neg_pos_ub=-1,
                add_gt_as_proposals=False),
            allowed_border=0,
            pos_weight=-1,
            debug=False,
            smoothl1_beta=0.1111111111111111),
        rcnn=dict(
            assigner=dict(
                type='MaxIoUAssignerCenterness',
                pos_iou_thr=0.5,
                neg_iou_thr=0.5,
                min_pos_iou=0.5,
                match_low_quality=False,
                ignore_iof_thr=-1),
            sampler=dict(
                type='RandomSampler',
                num=512,
                pos_fraction=0.25,
                neg_pos_ub=-1,
                add_gt_as_proposals=True),
            pos_weight=-1,
            debug=False)),
    test_cfg=dict(
        rpn=dict(
            nms_pre=500,
            max_per_img=100,
            nms=dict(type='nms', iou_threshold=0.7),
            min_bbox_size=0),
        rcnn=dict(
            score_thr=0.05,
            nms=dict(type='nms', iou_threshold=0.5),
            max_per_img=100)))
