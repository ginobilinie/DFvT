_base_ = [
    '../../_base_/models/upsnet_mobv2_fpn_fcn.py',
    '../../_base_/datasets/socol_panoptic.py',
    '../../_base_/schedules/schedule_1x.py', '../../_base_/default_runtime.py'
]

data_root = '/home/rlan/datasets/detect/socol_hd_12w_inst14_roadmask/'
data = dict(
    train=dict(
        ann_file=data_root + 'ig_small_annotations/hd_train.json',
        img_prefix=data_root + 'images/',
        seg_prefix=data_root + 'reduce_semantic_labels/',
        test_mode=False),
    val=dict(
        ann_file=data_root + 'ig_small_annotations/hd_test.json',
        coco_gt_file=data_root + 'ig_small_annotations\
/instance_annotations_test.json',
        img_prefix=data_root + 'images/',
        seg_prefix=data_root + 'reduce_semantic_labels/',
        test_mode=True),
)
optimizer = dict(type='SGD', lr=0.02, momentum=0.9, weight_decay=0.0001)
optimizer_config = dict(
    _delete_=True, grad_clip=dict(max_norm=35, norm_type=2))
# learning policy
lr_config = dict(
    policy='step',
    warmup='linear',
    warmup_iters=500,
    warmup_ratio=0.001,
    step=[8, 11])
runner = dict(type='EpochBasedRunner', max_epochs=12)
