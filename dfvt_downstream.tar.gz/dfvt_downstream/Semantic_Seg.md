train:

nohup tools/dist_train.sh configs/semanticSeg/semSeg_3x_sd.py 8 --cfg-options model.pretrained=pretrained/swin_tiny_patch4_window7_224.pth model.backbone.use_checkpoint=True --no-validate >log_train_swin_ssegformer_0426.txt 2>&1 &

inference:

python tools/inference_mmPanopticSeg.py configs/semanticSeg/semSeg_3x_sd.py work_dirs/semSeg_3x_sd/epoch_36.pth --data-path /data/wx303649/project/LaneDetection/datasets/lane/lane_wx_coco/images_test_raw --sseg-save-path result/xx/

evaluation:

python tools/eval_sseg_dist.py --gt-dir /data/wx303649/project/PanopticSegmentation/codes/mmPanopticSeg/results/solov2_r101_dcn_fpn_3x_last_fpn_ohem_normal_thr_035/semantic_labels_test_normal --pred-dir result/xx/sseg/ --num-classes 14 --process-num 20
